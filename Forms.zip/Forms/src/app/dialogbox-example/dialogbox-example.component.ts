import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dialogbox-example',
  templateUrl: './dialogbox-example.component.html',
  styleUrls: ['./dialogbox-example.component.css']
})
export class DialogboxExampleComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
