import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DialogboxExampleComponent } from './dialogbox-example.component';

describe('DialogboxExampleComponent', () => {
  let component: DialogboxExampleComponent;
  let fixture: ComponentFixture<DialogboxExampleComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DialogboxExampleComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DialogboxExampleComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
