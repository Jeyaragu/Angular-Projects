import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-forms',
  templateUrl: './forms.component.html',
  styleUrls: ['./forms.component.css']
})
export class FormsComponent implements OnInit {
  validations = new FormGroup({
    fname:new FormControl('',Validators.required),
    mobile: new FormControl('', [
      Validators.required,
      Validators.minLength(10)
    ]),
    email: new FormControl('',[
      Validators.required,
      Validators.email
    ]),
    pan:new FormControl('',[
      Validators.required
    ])
  });
  constructor() { }
  onSubmit(){
    console.log(this.validations.value);
  }
  ngOnInit(): void {
  }

}
