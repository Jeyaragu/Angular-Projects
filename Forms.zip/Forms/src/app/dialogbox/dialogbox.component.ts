import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { DialogboxExampleComponent } from '../dialogbox-example/dialogbox-example.component';

@Component({
  selector: 'app-dialogbox',
  templateUrl: './dialogbox.component.html',
  styleUrls: ['./dialogbox.component.css']
})
export class DialogboxComponent implements OnInit {

  constructor( public dialog:MatDialog) { }
  openDialog(){
   let dialogref =  this.dialog.open(DialogboxExampleComponent,{
     width:'400px'
   });
   dialogref.afterClosed().subscribe(result =>{
     console.log(result);
   })
  }
  ngOnInit(): void {
  }

}
